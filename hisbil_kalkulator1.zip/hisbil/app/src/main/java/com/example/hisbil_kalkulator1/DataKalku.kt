package com.example.hisbil_kalkulator1

data class DataKalku(
    val hasil : Double
)
